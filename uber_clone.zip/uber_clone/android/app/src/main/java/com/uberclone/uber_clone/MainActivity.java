package com.uberclone.uber_clone;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
