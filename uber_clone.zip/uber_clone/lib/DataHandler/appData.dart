import 'package:flutter/cupertino.dart';

class AppData extends ChangeNotifier
{

}